{
	"name"; "ELITE-PRO-V2 Bot Multi Device "
}